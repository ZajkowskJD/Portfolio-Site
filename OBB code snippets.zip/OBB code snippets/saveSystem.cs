using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class saveSystem
{
    public static void SaveLog(GameObject gameManager)
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/log.dat";
        FileStream stream = new FileStream(path, FileMode.Create);

        playerData data = new playerData(gameManager);

        formatter.Serialize(stream, data);
        stream.Close();
        
    }

    public static playerData LoadLog()
    {
        string path = Application.persistentDataPath + "/log.dat";
        if (File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);
            playerData data = formatter.Deserialize(stream) as playerData;
            stream.Close();

            return data;
        }
        else
        {
            Debug.LogError("File not found");
            return null;
        }
    }
}
