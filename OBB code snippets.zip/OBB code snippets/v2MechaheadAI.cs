using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class v2MechaheadAI : MonoBehaviour
{
    [SerializeField] int maxHP = 200;
    [SerializeField] GameObject missilePrefab;
    [SerializeField] GameObject hitParticles;
    [SerializeField] Transform[] firePoints;
    private GameObject healthVisual;
    private GameObject healthUpdate;
    [SerializeField] Transform floorDetector;
    private float currentHP;
    private Animator anim;
    private Rigidbody2D rb;
    private IEnumerator routine;
    private bool performed = false;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        healthVisual = GameObject.Find("BossHealthVisual");
        healthUpdate = GameObject.Find("BossHealthUpdate");
        currentHP = maxHP;
    }

    public void StartMechahead()
    {
        GameObject.Find("BossUI").GetComponent<Canvas>().enabled = true;
        GameObject.FindGameObjectWithTag("camera").GetComponent<CinemachineVirtualCamera>().m_Lens.OrthographicSize *= 2;
        GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("mechaheadFight");
        MechaheadPattern();
    }

    private void MechaheadPattern()
    {
        routine = _pattern();
        StartCoroutine(_pattern());
        IEnumerator _pattern()
        {
            int position = 2;
            int[] possibleDestinations = { 1, 3 };

            while (currentHP > 0)
            {
                for (int i = 0; i < 3; i++)
                {
                    int chosenDestination = possibleDestinations[Random.Range(0, possibleDestinations.Length)];
                    switch (position)
                    {
                        case 1:
                            yield return StartCoroutine(one_two());
                            position = 2;
                            break;
                        case 2:
                            switch (chosenDestination)
                            {
                                case 1:
                                    yield return StartCoroutine(two_one());
                                    position = 1;
                                    break;
                                case 3:
                                    yield return StartCoroutine(two_three());
                                    position = 3;
                                    break;
                            }
                            break;
                        case 3:
                            yield return StartCoroutine(three_two());
                            position = 2;
                            break;
                    }
                    if (currentHP < 1) yield break;
                }

                if (currentHP < 1) yield break;

                if (position != 2)
                {
                    yield return StartCoroutine(missileLaunch());
                }
            }

            IEnumerator one_two()
            {
                GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("mechaheadJump");
                gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
                anim.SetBool("jump", true);
                anim.SetBool("grounded", false);
                yield return new WaitForSeconds(.3f);
                rb.gravityScale = 1;
                rb.AddForce(new Vector2(0, 5), ForceMode2D.Impulse);
                rb.velocity = new Vector2(16, rb.velocity.y);
                yield return new WaitForSeconds(1);
                rb.velocity = Vector2.zero;
                rb.gravityScale = 5;
                yield return new WaitForSeconds(3);
            }

            IEnumerator two_one()
            {
                GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("mechaheadJump");
                gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 180, 0));
                anim.SetBool("jump", true);
                anim.SetBool("grounded", false);
                yield return new WaitForSeconds(.3f);
                rb.gravityScale = 1;
                rb.AddForce(new Vector2(0, 10), ForceMode2D.Impulse);
                rb.velocity = new Vector2(-16, rb.velocity.y);
                yield return new WaitForSeconds(1);
                rb.velocity = Vector2.zero;
                rb.gravityScale = 5;
                yield return new WaitForSeconds(3);
            }

            IEnumerator two_three()
            {
                GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("mechaheadJump");
                gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
                anim.SetBool("jump", true);
                anim.SetBool("grounded", false);
                yield return new WaitForSeconds(.3f);
                rb.gravityScale = 1;
                rb.AddForce(new Vector2(0, 10), ForceMode2D.Impulse);
                rb.velocity = new Vector2(16, rb.velocity.y);
                yield return new WaitForSeconds(1);
                rb.velocity = Vector2.zero;
                rb.gravityScale = 5;
                yield return new WaitForSeconds(3);
            }

            IEnumerator three_two()
            {
                GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("mechaheadJump");
                gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 180, 0));
                anim.SetBool("jump", true);
                anim.SetBool("grounded", false);
                yield return new WaitForSeconds(.3f);
                rb.gravityScale = 1;
                rb.AddForce(new Vector2(0, 5), ForceMode2D.Impulse);
                rb.velocity = new Vector2(-16, rb.velocity.y);
                yield return new WaitForSeconds(1);
                rb.velocity = Vector2.zero;
                rb.gravityScale = 5;
                yield return new WaitForSeconds(3);
            }

            IEnumerator missileLaunch()
            {
                GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("chargeMissiles");
                anim.SetBool("ready", true);
                yield return new WaitForSeconds(.5f);
                int index = 0;
                foreach (Transform t in firePoints)
                {
                    Transform playerPos = GameObject.FindGameObjectWithTag("player").transform;
                    GameObject missile = Instantiate(missilePrefab, firePoints[index].position, firePoints[index].rotation, gameObject.transform);
                    missile.GetComponent<v2MissileController>().playerPos = playerPos;
                    index++;
                    yield return new WaitForSeconds(.2f);
                }
                yield return new WaitForSeconds(1.5f);
                anim.SetBool("launched", true);
                yield return new WaitForSeconds(3);
                anim.SetBool("ready", false);
                anim.SetBool("launched", false);
            }
        }
    }

    public void MechaheadDeathCutsceneNode1()
    {
        StartCoroutine(_death());
        IEnumerator _death()
        {
            GameObject.Find("BossUI").GetComponent<Canvas>().enabled = false;
            GameObject.FindGameObjectWithTag("camera").GetComponent<CinemachineVirtualCamera>().m_Lens.OrthographicSize /= 2;
            GetComponent<elevatorBomb>().BossDeath();
            anim.SetBool("die", true);
            yield return new WaitForSeconds(4);
            GameObject flash = GameObject.Find("Flash");
            GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("bigExplosion");
            flash.GetComponent<Canvas>().enabled = true;
            flash.GetComponent<Animator>().SetBool("flash", true);
            yield return new WaitForSeconds(.5f);
            GetComponent<SpriteRenderer>().enabled = false;
            yield return new WaitForSeconds(flash.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length - .5f);
            GetComponent<v2RunSpeech>().NextLine(-1);
            GameObject.FindGameObjectWithTag("Homer").GetComponent<v2RunSpeech>().StartDialogAt(4);
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        RaycastHit2D hit = Physics2D.Raycast(floorDetector.position, Vector2.down, 2, 1 << 3);
        Debug.DrawRay(floorDetector.position, Vector2.down, Color.green);
        Debug.Log(hit.transform.gameObject.name);
        Debug.Log(hit.point);
        if (hit && collision.gameObject.tag == "Floor")
        {
            Debug.Log("floor");
            StartCoroutine(_grounded());
            return;
        }
        if (collision.gameObject.tag == "playerWeapon")
        {
            Instantiate(hitParticles, collision.GetComponent<projectileManager>().point, Quaternion.identity);
            currentHP -= collision.gameObject.GetComponent<projectileManager>().dmg;
            GameObject.Find("GameManager v2").GetComponent<textOverlayController>().GenerateNewTextParticle(transform.position, Quaternion.identity, "-" + collision.gameObject.GetComponent<projectileManager>().dmg.ToString(), new Vector3(214, 26, 82));
            healthVisual.transform.localScale = new Vector3(currentHP / maxHP, 1, 1);
        }

        IEnumerator _grounded()
        {
            rb.gravityScale = 0;
            rb.velocity = Vector2.zero;
            transform.position = new Vector2(hit.point.x, Mathf.Round(hit.point.y)) + new Vector2(0, 3);
            anim.SetBool("grounded", true);
            GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("mechaheadLand");
            yield return new WaitForSeconds(anim.GetCurrentAnimatorStateInfo(0).length);
            anim.SetBool("jump", false);
        }
    }

    private void FixedUpdate()
    {
        if (healthUpdate.transform.localScale != healthVisual.transform.localScale)
        {
            healthUpdate.transform.localScale = new Vector3(healthUpdate.transform.localScale.x - .01f, 1, 1);
        }
        if(anim.GetBool("ready"))
        {
            int rotationVal = 0;
            if (GameObject.FindGameObjectWithTag("player").transform.position.x > transform.position.x) rotationVal = 0;
            else rotationVal = 180;
            transform.rotation = Quaternion.Euler(new Vector3(transform.rotation.x, rotationVal));
        }

    }

    private void Update()
    {
        if (currentHP < 1 && performed == false)
        {
            StopCoroutine(routine);
            GetComponent<v2RunSpeech>().StartDialog();
            performed = true;
        }
    }

}
