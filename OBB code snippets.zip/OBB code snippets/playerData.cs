using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class playerData
{
    public int level;
    public int health;
    public int maxHealth;
    
    public float[] position;

    public int[] weapon_ids = new int[8];
    public int[] weapon_currentXP = new int[8];
    public int[] weapon_currentLVL = new int[8];
    public int[] keyItem_ids = new int[18];

    public bool[] chestStatuses;
    public bool[] cutsceneStatuses;

    public playerData (GameObject gameManager)
    {
        level = gameManager.GetComponent<saveDataCollector>().level;
        health = gameManager.GetComponent<saveDataCollector>().health;
        maxHealth = gameManager.GetComponent<saveDataCollector>().maxHealth;
        position = new float[2];
        position[0] = gameManager.GetComponent<saveDataCollector>().position[0];
        position[1] = gameManager.GetComponent<saveDataCollector>().position[1];
        weapon_ids = gameManager.GetComponent<saveDataCollector>().weapon_ids;
        weapon_currentXP = gameManager.GetComponent<saveDataCollector>().weapon_currentXP;
        weapon_currentLVL = gameManager.GetComponent<saveDataCollector>().weapon_currentLVL;
        keyItem_ids = gameManager.GetComponent<saveDataCollector>().keyItem_ids;
        chestStatuses = gameManager.GetComponent<saveDataCollector>().chestStatuses;
        cutsceneStatuses = gameManager.GetComponent<saveDataCollector>().cutsceneStatuses;
    }
}
