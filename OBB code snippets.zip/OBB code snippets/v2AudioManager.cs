using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class v2AudioManager : MonoBehaviour
{
    [SerializeField] v2Sound[] importedSounds;
    private Dictionary<string, v2Sound> soundDictionary;
    [SerializeField] string[] levelBGMs;
    [SerializeField] GameObject audioSourceHolder;

    // Start is called before the first frame update
    void Awake()
    {
        soundDictionary = new Dictionary<string, v2Sound>();
        foreach (v2Sound s in importedSounds)
        {
            s.source = Instantiate(audioSourceHolder, transform.Find("AudioSources")).GetComponent<AudioSource>();
            s.source.clip = s.clip;
            s.source.volume = s.volume;
            s.source.loop = s.loop;
            soundDictionary.Add(s.name, s);
        }
    }
    
    public void Play(string name)
    {
        soundDictionary[name].source.Play();
        soundDictionary[name].playing = true;
        StartCoroutine(_MarkComplete(name));
    }

    public void Play(string name, AudioSource source)
    {
        source.clip = soundDictionary[name].clip;
        source.Play();
        soundDictionary[name].playing = true;
        StartCoroutine(_MarkComplete(name));
    }

    public void Stop(string name)
    {
        soundDictionary[name].source.Stop();
        soundDictionary[name].playing = false;
    }

    public void StopAll()
    {
        foreach(v2Sound s in importedSounds)
        {
            if(s.playing)
            {
                s.source.Stop();
                s.playing = false;
            }
        }
    }

    public void CheckJukebox()
    {
        int index = GetComponent<sceneTracker>().GetSceneIndex();
        if(levelBGMs[index] == string.Empty)
        {
            StopAll();
            return;
        }
        if(!soundDictionary[levelBGMs[index]].playing)
        {
            StopAll();
            Play(soundDictionary[levelBGMs[index]].name);
            Debug.Log("playing " + soundDictionary[levelBGMs[index]].name);
        }
    }

    public v2Sound GetSound(string name)
    {
        return soundDictionary[name];
    }

    private IEnumerator _MarkComplete(string name)
    {
        yield return new WaitForSeconds(soundDictionary[name].clip.length);
        soundDictionary[name].playing = false;
    }

}
