using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using Cinemachine;

public class v2RunSpeech : MonoBehaviour
{
    private GameObject dialogUI;
    private GameObject choiceArrow;
    private Image dialogPortrait;
    private TextMeshProUGUI textComponent;
    private int index = 0;
    [SerializeField] Sprite blank;
    [SerializeField] speechNodev2[] dialogTree;
    private float speedModifier = 1;
    private PlayerControls playerControls;
    private int indexFromChoice = -1;
    private bool skipped = false;
    private bool started = false;

    void Start()
    {
        playerControls = GameObject.FindGameObjectWithTag("player").GetComponent<v2PlayerController>().playerControls;
        dialogUI = GameObject.Find("DialogUI v2");
        dialogPortrait = dialogUI.transform.Find("SpeakerPortrait").GetComponent<Image>();
        textComponent = dialogUI.transform.Find("DialogText").GetComponent<TextMeshProUGUI>();
        textComponent.text = string.Empty;
        dialogUI.GetComponent<dialogChoiceToggle>().activateChoice();
        choiceArrow = dialogUI.transform.Find("Y N Backdrop").transform.Find("Pointer").gameObject;
        dialogUI.GetComponent<dialogChoiceToggle>().deactivateChoice();
    }

    private void Update()
    {
        if (GameObject.FindGameObjectWithTag("focus") && started)
            GameObject.FindGameObjectWithTag("focus").transform.position = dialogTree[index].cameraFocus.position;
    }

    public void StartDialog()
    {
        started = true;
        index = 0;
        dialogUI.GetComponent<Canvas>().enabled = true;
        if(GameObject.Find("GameManager v2").GetComponent<controlsManager>().GetActiveMap() == "player") GameObject.FindGameObjectWithTag("player").GetComponent<v2PlayerController>().RemovePlayerMapFunctions();
        playerControls.Player.Disable();
        playerControls.Dialog.Enable();
        AddDialogMapFunctions();
        if(GameObject.FindGameObjectWithTag("focus"))
        {
            GameObject.FindGameObjectWithTag("focus").GetComponent<lockToPlayer>().disableFocus = true;
        }
        StartCoroutine(TypeLine());
    }

    public void StartDialogAt(int newIndex)
    {
        started = true;
        index = newIndex;
        dialogUI.GetComponent<Canvas>().enabled = true;
        GameObject.FindGameObjectWithTag("player").GetComponent<v2PlayerController>().RemovePlayerMapFunctions();
        playerControls.Player.Disable();
        playerControls.Dialog.Enable();
        AddDialogMapFunctions();
        if(GameObject.FindGameObjectWithTag("focus"))
        {
            GameObject.FindGameObjectWithTag("focus").GetComponent<lockToPlayer>().disableFocus = true;
        }
        StartCoroutine(TypeLine());
    }

    private IEnumerator TypeLine()
    {
        if (dialogTree[index].showDialogUI)   dialogUI.GetComponent<Canvas>().enabled = true;
        else                                  dialogUI.GetComponent<Canvas>().enabled = false;

        if (dialogTree[index].action != null) dialogTree[index].action.Invoke();

        if (dialogTree[index].portraitToDisplay != null) dialogPortrait.sprite = dialogTree[index].portraitToDisplay;
        else dialogPortrait.sprite = blank;

        if (GameObject.FindGameObjectWithTag("focus")) 
            GameObject.FindGameObjectWithTag("focus").transform.position = dialogTree[index].cameraFocus.position;
        if (dialogTree[index].textToDisplay == string.Empty)
        {
            NextLine(-1);
        }

        if(dialogTree[index].altNode == -1)
            dialogUI.GetComponent<dialogChoiceToggle>().deactivateChoice();
        foreach(char c in dialogTree[index].textToDisplay.ToCharArray())
        {
            if (skipped) {
                if (dialogTree[index].altNode != -1)
                {
                    dialogUI.GetComponent<dialogChoiceToggle>().activateChoice();
                    indexFromChoice = dialogTree[index].nextNode;
                }
                yield break;
            } 
            else
            {
                textComponent.text += c;
                if(dialogTree[index].showDialogUI) GameObject.Find("GameManager v2").GetComponent<v2AudioManager>().Play("textUpdateNoise");
                yield return new WaitForSeconds(dialogTree[index].textSpeed * speedModifier);
            }
        }
        if(dialogTree[index].altNode != -1)
        {
            dialogUI.GetComponent<dialogChoiceToggle>().activateChoice();
            indexFromChoice = dialogTree[index].nextNode;
        }

    }

    public void NextLine(int nextNode)
    {
        skipped = false;
        if(nextNode == -1)
        {
            started = false;
            textComponent.text = string.Empty;
            HoverYes();
            dialogUI.GetComponent<dialogChoiceToggle>().deactivateChoice();
            dialogPortrait.sprite = blank;
            dialogUI.GetComponent<Canvas>().enabled = false;
            RemoveDialogMapFunctions();
            playerControls.Dialog.Disable();
            playerControls.Player.Enable();
            GameObject.FindGameObjectWithTag("player").GetComponent<v2PlayerController>().AddPlayerMapFunctions();
            if(GameObject.FindGameObjectWithTag("focus"))
            {
                GameObject.FindGameObjectWithTag("focus").GetComponent<lockToPlayer>().disableFocus = false;
            }
            if(gameObject.tag == "cutscene")
            {
                GameObject.Find("GameManager v2").GetComponent<saveManager>()._playerData.cutsceneStatuses[GetComponent<v2CutsceneTrigger>().GetCutsceneID()] = true;
                Destroy(gameObject);
            }
            return;
        }
        index = nextNode;
        textComponent.text = string.Empty;
        StartCoroutine(TypeLine());
    }

    private void HoverYes()
    {
        choiceArrow.GetComponent<RectTransform>().position = new Vector3(1400, 190, 0);
        indexFromChoice = dialogTree[index].nextNode;
    }

    private void HoverNo()
    {
        choiceArrow.GetComponent<RectTransform>().position = new Vector3(1600, 190, 0);
        indexFromChoice = dialogTree[index].altNode;
    }

    //*********************
    // DIALOG MAP FUNCTIONS
    //*********************

    public void AddDialogMapFunctions()
    {
        playerControls.Dialog.AdvanceText.performed += AdvanceText_performed;
        playerControls.Dialog.AdvanceText.canceled += AdvanceText_canceled;
        playerControls.Dialog.SkipText.performed += SkipText_performed;
        playerControls.Dialog.NavigateLeft.performed += NavigateLeft_performed;
        playerControls.Dialog.NavigateRight.performed += NavigateRight_performed;
    }

    public void RemoveDialogMapFunctions()
    {
        playerControls.Dialog.AdvanceText.performed -= AdvanceText_performed;
        playerControls.Dialog.AdvanceText.canceled -= AdvanceText_canceled;
        playerControls.Dialog.SkipText.performed -= SkipText_performed;
        playerControls.Dialog.NavigateLeft.performed -= NavigateLeft_performed;
        playerControls.Dialog.NavigateRight.performed -= NavigateRight_performed;
    }

    private void AdvanceText_performed(InputAction.CallbackContext context)
    {
        if (dialogTree[index].manualAdvanceDisabled) return;

        if(textComponent.text == dialogTree[index].textToDisplay && dialogTree[index].altNode == -1)
        {
            NextLine(dialogTree[index].nextNode);
            return;
        }
        if (textComponent.text == dialogTree[index].textToDisplay && dialogTree[index].altNode != -1)
        {
            NextLine(indexFromChoice);
            return;
        }
            if (dialogTree[index].canAccelerateTextSpeed) speedModifier = .5f;
    }

    private void AdvanceText_canceled(InputAction.CallbackContext context)
    {
        speedModifier = 1;
    }

    private void SkipText_performed(InputAction.CallbackContext context)
    {
        if (dialogTree[index].manualAdvanceDisabled) return;

        if (dialogTree[index].canAccelerateTextSpeed) {
            skipped = true;
            textComponent.text = dialogTree[index].textToDisplay;
        } 
    }

    private void NavigateLeft_performed(InputAction.CallbackContext context)
    {
        if(!dialogUI.GetComponent<dialogChoiceToggle>().getActive())
        {
            return;
        }
        if(indexFromChoice == dialogTree[index].nextNode)
        {
            HoverNo();
            return;
        }
        if(indexFromChoice == dialogTree[index].altNode)
        {
            HoverYes();
            return;
        }
    }

    private void NavigateRight_performed(InputAction.CallbackContext context)
    {
        
        if (!dialogUI.GetComponent<dialogChoiceToggle>().getActive())
        {
            return;
        }
        if (indexFromChoice == dialogTree[index].nextNode)
        {
            HoverNo();
            return;
        }
        if (indexFromChoice == dialogTree[index].altNode)
        {
            HoverYes();
            return;
        }
    }

}
